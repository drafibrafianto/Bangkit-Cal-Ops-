package com.example.simtaster.di

import com.example.core.domain.usecase.auth.LoginInteractor
import com.example.core.domain.usecase.auth.LoginUseCase
import com.example.core.domain.usecase.auth.RegisterInteractor
import com.example.core.domain.usecase.auth.RegisterUseCase
import com.example.core.domain.usecase.pond.*
import com.example.core.domain.usecase.profile.GetUserProfileInteractor
import com.example.core.domain.usecase.profile.GetUserProfileUseCase
import com.example.core.domain.usecase.reminder.*
import com.example.core.domain.usecase.statistics.GetRealtimeInteractor
import com.example.core.domain.usecase.statistics.GetRealtimeUseCase
import com.example.core.domain.usecase.statistics.GetStatisticsInteractor
import com.example.core.domain.usecase.statistics.GetStatisticsUseCase
import com.example.simtaster.preference.ReminderPreference
import com.example.simtaster.presentation.addreminder.AddReminderViewModel
import com.example.simtaster.presentation.alarm.AlarmViewModel
import com.example.simtaster.presentation.detailreminder.DetailReminderViewModel
import com.example.simtaster.presentation.home.HomeViewModel
import com.example.simtaster.presentation.login.LoginViewModel
import com.example.simtaster.presentation.profile.ProfileViewModel
import com.example.simtaster.presentation.realtime.RealtimeViewModel
import com.example.simtaster.presentation.register.RegisterViewModel
import com.example.simtaster.presentation.reminder.ReminderViewModel
import com.example.simtaster.presentation.statistics.StatisticsViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val preferenceModule = module {
    single { ReminderPreference(get()) }
}

val useCaseModule = module {
    single<RegisterUseCase> { RegisterInteractor(get()) }
    single<LoginUseCase> { LoginInteractor(get()) }
    single<AddPondUseCase> { AddPondInteractor(get()) }
    single<GetPondUseCase> { GetPondInteractor(get()) }
    single<DeletePondUseCase> { DeletePondInteractor(get()) }
    single<UpdatePondUseCase> { UpdatePondInteractor(get()) }
    single<GetStatisticsUseCase> { GetStatisticsInteractor(get()) }
    single<GetUserProfileUseCase> { GetUserProfileInteractor(get()) }
    single<GetRealtimeUseCase> { GetRealtimeInteractor(get()) }
    single<InsertReminderUseCase> { InsertReminderInteractor(get()) }
    single<GetReminderUseCase> { GetReminderInteractor(get()) }
    single<GetReminderByIdUseCase> { GetReminderByIdInteractor(get()) }
    single<DeleteReminderUseCase> { DeleteReminderInteractor(get()) }
    single<UpdateTimeReminderUseCase> { UpdateTimeReminderInteractor(get()) }
    single<UpdateReminderUseCase> { UpdateReminderInteractor(get()) }
}

val viewModelModule = module {
    viewModel { RegisterViewModel(get()) }
    viewModel { LoginViewModel(get()) }
    viewModel { HomeViewModel(get(), get(), get(), get()) }
    viewModel { StatisticsViewModel(get()) }
    viewModel { RealtimeViewModel(get()) }
    viewModel { ProfileViewModel(get()) }
    viewModel { AddReminderViewModel(get(), get()) }
    viewModel { ReminderViewModel(get()) }
    viewModel { DetailReminderViewModel(get(), get(), get()) }
    viewModel { AlarmViewModel(get(), get(), get()) }
}