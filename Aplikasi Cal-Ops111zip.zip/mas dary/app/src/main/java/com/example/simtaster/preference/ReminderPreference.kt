package com.example.simtaster.preference

import android.content.Context
import androidx.core.content.edit
import com.example.core.domain.model.Reminder
import com.google.gson.Gson

class ReminderPreference(context: Context) {
    companion object {
        private const val PREFS_NAME = "reminder_pref"
    }

    private val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun setReminder(key: String, reminder: Reminder) {
        val gson = Gson()
        val json = gson.toJson(reminder)

        preferences.edit {
            putString(key, json)
        }
    }

    fun getReminder(): List<Reminder> {
        val allReminderPref = preferences.all
        val gson = Gson()

        return allReminderPref.map {
            gson.fromJson(it.value as String, Reminder::class.java)
        }
    }

    fun deleteReminder(key: String) {
        preferences.edit {
            remove(key)
        }
    }
}