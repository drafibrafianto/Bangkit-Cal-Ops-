package com.example.simtaster.presentation.addreminder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.core.domain.model.Reminder
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentAddReminderBinding
import com.example.simtaster.preference.ReminderPreference
import com.example.simtaster.service.AlarmReceiver
import com.example.simtaster.utils.Constant.reminderTypeList
import com.example.simtaster.utils.DateFormatter
import com.example.simtaster.utils.toast
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.DateValidatorPointForward
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

class AddReminderFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentAddReminderBinding? = null
    private val binding get() = _binding!!
    private val addReminderViewModel: AddReminderViewModel by viewModel()
    private val args: AddReminderFragmentArgs by navArgs()
    private val reminderPreference: ReminderPreference by inject()

    private lateinit var alarmReceiver: AlarmReceiver
    private lateinit var reminderCalendar: Calendar
    private var date: String? = null
    private var hour: Int = 0
    private var minute: Int = 0
    private var isAdd: Boolean = true
    private lateinit var reminderData: Reminder

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAddReminderBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        reminderCalendar = Calendar.getInstance()
        alarmReceiver = AlarmReceiver()

        isAdd = args.isAdd

        if (!isAdd) {
            reminderData = args.reminder as Reminder

            with(binding) {
                etTitle.setText(reminderData.title)
                etDate.setText(DateFormatter.formatTimeMillisToDateStyle(reminderData.reminderTime))
                etTime.setText(DateFormatter.formatTimeMillisToTimeStyle(reminderData.reminderTime))

                date = DateFormatter.formatTimeMillisToDateAlarmStyle(reminderData.reminderTime)

                val time =
                    DateFormatter.formatTimeMillisToTimeStyle(reminderData.reminderTime).split(":")
                hour = time[0].toInt()
                minute = time[1].toInt()

                if (reminderData.reminderType == reminderTypeList[0]) {
                    spnReminderType.setText(reminderTypeList[0])
                } else {
                    spnReminderType.setText(reminderTypeList[1])
                }
            }
            reminderCalendar.timeInMillis = reminderData.reminderTime
        }

        setReminderTypeAdapter()

        binding.etDate.setOnClickListener(this)
        binding.etTime.setOnClickListener(this)
        binding.btnSaveReminder.setOnClickListener(this)
    }

    private fun setReminderTypeAdapter() {
        val spinnerAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            reminderTypeList
        )

        binding.spnReminderType.setAdapter(spinnerAdapter)
    }

    private fun showDatePicker() {

        val today = MaterialDatePicker.todayInUtcMilliseconds()
        val constraintsBuilder = CalendarConstraints.Builder()
        val dateValidator = DateValidatorPointForward.now()
        constraintsBuilder.setValidator(dateValidator)

        constraintsBuilder.setStart(today)
        val materialDateBuilder =
            MaterialDatePicker.Builder.datePicker()
                .setTitleText(resources.getString(R.string.select_a_reminder_date_title))
                .setSelection(today).setCalendarConstraints(constraintsBuilder.build())
        val datePicker = materialDateBuilder.build()

        datePicker.show(childFragmentManager, DATE_PICKER_DIALOG_TAG)

        datePicker.addOnPositiveButtonClickListener {
            binding.etDate.setText(DateFormatter.formatTimeMillisToDateStyle(it))
            date = DateFormatter.formatTimeMillisToDateAlarmStyle(it)

            val dateCalendar = Calendar.getInstance()
            dateCalendar.timeInMillis = it
            reminderCalendar.set(Calendar.DAY_OF_MONTH, dateCalendar.get(Calendar.DAY_OF_MONTH))
            reminderCalendar.set(Calendar.MONTH, dateCalendar.get(Calendar.MONTH))
            reminderCalendar.set(Calendar.YEAR, dateCalendar.get(Calendar.YEAR))

        }
    }

    private fun showTimePicker() {
        val materialTimeBuilder =
            MaterialTimePicker.Builder().setTimeFormat(TimeFormat.CLOCK_24H).setHour(hour)
                .setMinute(minute)
        val timePicker = materialTimeBuilder.build()

        timePicker.show(childFragmentManager, TIME_PICKER_DIALOG_TAG)

        timePicker.addOnPositiveButtonClickListener {
            val newHour = timePicker.hour
            val newMinute = timePicker.minute
            onTimeSet(newHour, newMinute)
        }
    }

    private fun onTimeSet(newHour: Int, newMinute: Int) {
        reminderCalendar.set(Calendar.HOUR_OF_DAY, newHour)
        reminderCalendar.set(Calendar.MINUTE, newMinute)
        reminderCalendar.set(Calendar.SECOND, 0)
        reminderCalendar.isLenient = false

        val time = DateFormatter.formatTimeMillisToTimeStyle(reminderCalendar.timeInMillis)
        binding.etTime.setText(time)
        hour = newHour
        minute = newMinute
    }

    private fun saveReminder(
        title: String,
        reminderType: String
    ) {
        val reminder = Reminder(
            0,
            title,
            reminderCalendar.timeInMillis,
            reminderType
        )

        addReminderViewModel.insertReminder(reminder).observe(this, { reminderId ->
            if (reminderId > 0) {
                reminder.id = reminderId.toInt()

                reminderPreference.setReminder(reminderId.toString(), reminder)

                if (reminderType == reminderTypeList[0]) {
                    alarmReceiver.setAlarm(
                        requireContext(),
                        AlarmReceiver.TYPE_ONE_TIME,
                        reminderId.toInt(),
                        reminderCalendar.timeInMillis,
                        title,
                        isAdd
                    )
                } else {
                    alarmReceiver.setAlarm(
                        requireContext(),
                        AlarmReceiver.TYPE_REPEATING,
                        reminderId.toInt(),
                        reminderCalendar.timeInMillis,
                        title,
                        isAdd
                    )
                }

                context?.toast(resources.getString(R.string.reminder_saved))
                findNavController().popBackStack()
            }
        })
    }

    private fun updateReminder(
        title: String,
        reminderType: String
    ) {
        val reminder = Reminder(
            reminderData.id,
            title,
            reminderCalendar.timeInMillis,
            reminderType
        )

        addReminderViewModel.updateReminder(reminder)
        reminderPreference.setReminder(reminderData.id.toString(), reminder)

        if (reminderType == reminderTypeList[0]) {
            alarmReceiver.setAlarm(
                requireContext(),
                AlarmReceiver.TYPE_ONE_TIME,
                reminderData.id,
                reminderCalendar.timeInMillis,
                title,
                isAdd
            )
        } else {
            alarmReceiver.setAlarm(
                requireContext(),
                AlarmReceiver.TYPE_REPEATING,
                reminderData.id,
                reminderCalendar.timeInMillis,
                title,
                isAdd
            )
        }
        context?.toast(resources.getString(R.string.reminder_updated))
        findNavController().popBackStack()
    }

    private fun showConfirmDialog(
        title: String,
        reminderType: String
    ) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(resources.getString(R.string.save_reminder_title))
            .setMessage(resources.getString(R.string.save_reminder_message))
            .setNegativeButton(resources.getString(R.string.decline_text)) { _, _ ->
            }
            .setPositiveButton(resources.getString(R.string.accept_text)) { _, _ ->
                if (isAdd) {
                    saveReminder(title, reminderType)
                } else {
                    updateReminder(title, reminderType)
                }

            }.show()
    }

    override fun onClick(view: View) {
        when (view) {
            binding.etDate -> showDatePicker()
            binding.etTime -> {
                if (hour == 0 && minute == 0) {
                    val calendar = Calendar.getInstance()
                    val hour = calendar.get(Calendar.HOUR_OF_DAY)
                    val minute = calendar.get(Calendar.MINUTE)

                    this.hour = hour
                    this.minute = minute
                }

                showTimePicker()
            }
            binding.btnSaveReminder -> {
                val title = binding.etTitle.text.toString()
                val date = this.date
                val time = binding.etTime.text.toString()
                val reminderType = binding.spnReminderType.text.toString()

                if (title.isEmpty() || date.isNullOrEmpty() || time.isEmpty() || reminderType.isEmpty()) {
                    context?.toast(resources.getString(R.string.field_reminder_empty))
                } else {
                    showConfirmDialog(title, reminderType)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    companion object {
        const val DATE_PICKER_DIALOG_TAG = "date picker"
        const val TIME_PICKER_DIALOG_TAG = "time picker"
    }
}