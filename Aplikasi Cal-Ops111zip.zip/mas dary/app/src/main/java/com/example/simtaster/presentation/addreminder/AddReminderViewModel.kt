package com.example.simtaster.presentation.addreminder

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.domain.model.Reminder
import com.example.core.domain.usecase.reminder.InsertReminderUseCase
import com.example.core.domain.usecase.reminder.UpdateReminderUseCase

class AddReminderViewModel(
    private val insertReminderUseCase: InsertReminderUseCase,
    private val updateReminderUseCase: UpdateReminderUseCase
) : ViewModel() {
    fun insertReminder(reminder: Reminder): LiveData<Long> =
        LiveDataReactiveStreams.fromPublisher(insertReminderUseCase.insertReminder(reminder))

    fun updateReminder(reminder: Reminder) = updateReminderUseCase.updateReminder(reminder)
}