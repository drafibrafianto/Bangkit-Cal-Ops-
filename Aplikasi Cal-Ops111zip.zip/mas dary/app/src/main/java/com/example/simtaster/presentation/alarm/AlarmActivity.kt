package com.example.simtaster.presentation.alarm

import android.app.AlarmManager
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.core.domain.model.Reminder
import com.example.simtaster.R
import com.example.simtaster.databinding.ActivityAlarmBinding
import com.example.simtaster.preference.ReminderPreference
import com.example.simtaster.service.AlarmReceiver
import com.example.simtaster.service.AlarmService
import com.example.simtaster.utils.Constant.reminderTypeList
import com.example.simtaster.utils.DateFormatter
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel

class AlarmActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityAlarmBinding
    private lateinit var alarmReceiver: AlarmReceiver
    private val alarmViewModel: AlarmViewModel by viewModel()
    private val reminderPreference: ReminderPreference by inject()

    private var reminderId: Int = 0
    private var reminderTime: Long = 0
    private lateinit var title: String
    private lateinit var reminderType: String
    private lateinit var reminder: Reminder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAlarmBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        or WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
            )
        }

        with(getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                requestDismissKeyguard(this@AlarmActivity, null)
            }
        }

        setReminderData()

        alarmReceiver = AlarmReceiver()
        binding.btnStopReminder.setOnClickListener(this)

    }

    private fun setReminderData() {
        reminderId = intent.getIntExtra(AlarmReceiver.ALARM_ID, 0)

        alarmViewModel.getReminderById(reminderId).observe(this, { data ->
            title = data.title
            reminderTime = data.reminderTime
            reminderType = data.reminderType

            reminder = Reminder(reminderId, title, reminderTime, reminderType)

            with(binding) {
                tvTitleReminder.text = title
                tvTimeReminder.text = DateFormatter.formatTimeMillisToTimeStyle(reminderTime)
                tvDateReminder.text = DateFormatter.formatTimeMillisToDateStyle(reminderTime)
            }
        })
    }

    private fun stopReminder() {

        if (reminderType == reminderTypeList[0]) {
            deleteReminder()
        } else {
            updateReminderTime()
        }

        val alarmService = Intent(this, AlarmService::class.java)
        stopService(alarmService)

        finish()
    }

    private fun deleteReminder() {
        alarmViewModel.deleteReminder(reminder)
        reminderPreference.deleteReminder(reminderId.toString())
        alarmReceiver.cancelAlarm(this, reminderId)
    }

    private fun updateReminderTime() {
        val interval = AlarmManager.INTERVAL_DAY

        while (reminderTime < System.currentTimeMillis()) {
            reminderTime += interval
        }

        reminder.reminderTime = reminderTime
        alarmViewModel.updateReminderTime(reminderId, reminderTime)
        reminderPreference.setReminder(reminderId.toString(), reminder)
    }

    override fun onClick(view: View) {
        if (view.id == R.id.btn_stop_reminder) {
            stopReminder()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(false)
            setTurnScreenOn(false)
        } else {
            window.clearFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        or WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
            )
        }
    }
}