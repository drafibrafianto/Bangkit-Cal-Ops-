package com.example.simtaster.presentation.detailreminder

import android.app.AlarmManager
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.navigation.ui.NavigationUI
import com.example.core.domain.model.Reminder
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentDetailReminderBinding
import com.example.simtaster.preference.ReminderPreference
import com.example.simtaster.service.AlarmReceiver
import com.example.simtaster.utils.Constant.reminderTypeList
import com.example.simtaster.utils.DateFormatter
import com.example.simtaster.utils.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel

class DetailReminderFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentDetailReminderBinding? = null
    private val binding get() = _binding!!
    private val detailReminderViewModel: DetailReminderViewModel by viewModel()
    private val args: DetailReminderFragmentArgs by navArgs()
    private val reminderPreference: ReminderPreference by inject()

    private lateinit var reminder: Reminder
    private lateinit var alarmReceiver: AlarmReceiver
    private var reminderId: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailReminderBinding.inflate(inflater, container, false)

        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        reminderId = args.reminderId

        alarmReceiver = AlarmReceiver()

        setDetailReminder(reminderId)

        binding.btnUpdateReminder.setOnClickListener(this)
    }

    private fun setDetailReminder(reminderId: Int) {
        detailReminderViewModel.getReminderById(reminderId)
            .observe(viewLifecycleOwner, { data ->
                reminder = data

                with(binding) {
                    tvTime.text = DateFormatter.formatTimeMillisToTimeStyle(data.reminderTime)
                    tvDate.text = DateFormatter.formatTimeMillisToDateStyle(data.reminderTime)
                    tvTitle.text = data.title
                    tvType.text = data.reminderType
                }
            })
    }

    private fun showDeleteConfirmDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(resources.getString(R.string.delete_reminder_text))
            .setMessage(resources.getString(R.string.delete_reminder_message))
            .setNegativeButton(resources.getString(R.string.decline_text)) { _, _ ->

            }
            .setPositiveButton(resources.getString(R.string.accept_text)) { _, _ ->
                deleteReminder(false)
            }.show()
    }

    private fun deleteReminder(isRefresh: Boolean) {
        detailReminderViewModel.deleteReminder(reminder)
        reminderPreference.deleteReminder(reminder.id.toString())

        alarmReceiver.cancelAlarm(requireContext(), reminderId)

        if (!isRefresh) {
            context?.toast(resources.getString(R.string.delete_reminder_success))
        }
        findNavController().popBackStack()
    }

    private fun refreshReminder() {
        var reminderTime = reminder.reminderTime
        val reminderType = reminder.reminderType
        val timeNow = System.currentTimeMillis()

        if (reminderType == reminderTypeList[0]) {
            if (reminderTime < timeNow) {
                deleteReminder(true)
            } else {
                alarmReceiver.setAlarm(
                    requireContext(),
                    AlarmReceiver.TYPE_ONE_TIME,
                    reminder.id,
                    reminderTime,
                    reminder.title,
                    true
                )
                setDetailReminder(reminderId)
            }
        } else {
            val interval = AlarmManager.INTERVAL_DAY

            while (reminderTime < timeNow) {
                reminderTime += interval
            }

            reminder.reminderTime = reminderTime
            detailReminderViewModel.updateReminderTime(reminder.id, reminderTime)
            reminderPreference.setReminder(reminder.id.toString(), reminder)

            alarmReceiver.setAlarm(
                requireContext(),
                AlarmReceiver.TYPE_REPEATING,
                reminder.id,
                reminderTime,
                reminder.title,
                true
            )
            setDetailReminder(reminderId)
        }
        context?.toast(resources.getString(R.string.reminder_refresh_message))
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.reminder_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.delete_item -> showDeleteConfirmDialog()
            R.id.item_refresh -> refreshReminder()
        }
        return NavigationUI.onNavDestinationSelected(
            item,
            view?.findNavController()!!
        ) || super.onOptionsItemSelected(item)
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    override fun onClick(view: View) {
        when (view) {
            binding.btnUpdateReminder -> {
                findNavController().navigate(
                    DetailReminderFragmentDirections.actionDetailReminderFragmentToAddReminderFragment(
                        resources.getString(R.string.update_reminder_text),
                        reminder,
                        false
                    )
                )
            }
        }
    }
}