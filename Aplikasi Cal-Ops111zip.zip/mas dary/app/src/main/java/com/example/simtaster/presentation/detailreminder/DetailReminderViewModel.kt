package com.example.simtaster.presentation.detailreminder

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.domain.model.Reminder
import com.example.core.domain.usecase.reminder.DeleteReminderUseCase
import com.example.core.domain.usecase.reminder.GetReminderByIdUseCase
import com.example.core.domain.usecase.reminder.UpdateTimeReminderUseCase

class DetailReminderViewModel(
    private val getReminderByIdUseCase: GetReminderByIdUseCase,
    private val deleteReminderUseCase: DeleteReminderUseCase,
    private val updateTimeReminderUseCase: UpdateTimeReminderUseCase
) : ViewModel() {

    fun getReminderById(reminderId: Int): LiveData<Reminder> =
        LiveDataReactiveStreams.fromPublisher(getReminderByIdUseCase.getReminderById(reminderId))

    fun deleteReminder(reminder: Reminder) = deleteReminderUseCase.deleteReminder(reminder)

    fun updateReminderTime(reminderId: Int, reminderTime: Long) =
        updateTimeReminderUseCase.updateReminderTime(reminderId, reminderTime)
}