package com.example.simtaster.presentation.dialog

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.DialogFragment
import com.example.core.domain.model.Pond
import com.example.simtaster.R
import com.example.simtaster.databinding.DialogAddPondBinding
import com.example.simtaster.utils.dismissDialog
import com.example.simtaster.utils.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class AddPondDialog : DialogFragment() {

    private var _binding: DialogAddPondBinding? = null
    private val binding get() = _binding!!
    private var actionType = ADD_ACTION
    private var data: Pond? = null
    private var pondId = ""

    var onButtonClick: ((String, String, String, String, String, String, String, String, String) -> Unit)? =
        null

    fun setData(actionType: String, data: Pond? = null) {
        this.actionType = actionType
        this.data = data
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAddPondBinding.inflate(LayoutInflater.from(context))
        val dialogBuilder = MaterialAlertDialogBuilder(requireContext())

        if (actionType == UPDATE_ACTION) {
            pondId = data?.id.toString()
            with(binding) {
                tvTitleAddPond.text = resources.getString(R.string.update_pond_text)
                tilLobsterType.editText?.setText(data?.lobsterType)
                tilNumberOfLobster.editText?.setText(data?.numberOfLobster)
                tilPondLength.editText?.setText(data?.length)
                tilPondWidth.editText?.setText(data?.width)
                tilPondHeight.editText?.setText(data?.height)
                tilIpAddress.editText?.setText(data?.ipAddress)
                tilPasswordCamera.editText?.setText(data?.password)
            }
        }

        binding.btnAddPond.setOnClickListener {
            val lobsterType = binding.tilLobsterType.editText?.text.toString()
            val numberOfLobster = binding.tilNumberOfLobster.editText?.text.toString()
            val pondLength = binding.tilPondLength.editText?.text.toString()
            val pondWidth = binding.tilPondWidth.editText?.text.toString()
            val pondHeight = binding.tilPondHeight.editText?.text.toString()
            val ipAddress = binding.tilIpAddress.editText?.text.toString()
            val password = binding.tilPasswordCamera.editText?.text.toString()

            if (lobsterType.isBlank() || numberOfLobster.isBlank() || pondLength.isBlank() || pondWidth.isBlank() || pondHeight.isBlank()) {
                context?.toast(resources.getString(R.string.data_not_complete_text))
            } else {
                onButtonClick?.invoke(
                    actionType,
                    pondId,
                    lobsterType,
                    numberOfLobster,
                    pondLength,
                    pondWidth,
                    pondHeight,
                    ipAddress,
                    password
                )
            }
        }

        dialogBuilder.setView(binding.root)

        return dialogBuilder.create()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)

        dismissDialog()
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    companion object {
        const val UPDATE_ACTION = "update"
        const val ADD_ACTION = "add"
    }
}