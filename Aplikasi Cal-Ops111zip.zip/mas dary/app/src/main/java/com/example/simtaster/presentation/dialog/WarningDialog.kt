package com.example.simtaster.presentation.dialog

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.DialogFragment
import com.example.simtaster.databinding.DialogWarningBinding
import com.example.simtaster.utils.dismissDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class WarningDialog : DialogFragment() {

    private var _binding: DialogWarningBinding? = null
    private val binding get() = _binding!!
    var onCloseButtonClick: (() -> Unit)? = null
    private var message = ""

    fun setWarningMessage(message: String) {
        this.message = message
        if (_binding != null) {
            binding.tvWarning.text = message
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogWarningBinding.inflate(LayoutInflater.from(context))
        val dialogBuilder = MaterialAlertDialogBuilder(requireContext())

        binding.tvWarning.text = message
        binding.btnClose.setOnClickListener {
            onCloseButtonClick?.invoke()
        }

        isCancelable = false
        dialogBuilder.setView(binding.root)

        return dialogBuilder.create()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)

        dismissDialog()
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }
}