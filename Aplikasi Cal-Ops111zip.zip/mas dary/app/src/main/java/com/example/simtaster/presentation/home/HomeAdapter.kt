package com.example.simtaster.presentation.home

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.core.domain.model.Pond
import com.example.simtaster.R
import com.example.simtaster.databinding.ItemPondBinding

class HomeAdapter : RecyclerView.Adapter<HomeAdapter.ViewHolder>() {

    private val listData = arrayListOf<Pond>()

    fun setData(newListData: List<Pond>?) {
        if (newListData == null) return
        listData.clear()
        listData.addAll(newListData)
        notifyDataSetChanged()
    }

    var onItemClick: ((Pond) -> Unit)? = null
    var onItemLongClick: ((Pond) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(
        ItemPondBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listData[position])
    }

    override fun getItemCount(): Int = listData.size

    inner class ViewHolder(private val binding: ItemPondBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Pond) {
            with(binding) {
                val statusBackground = tvPondStatus.background
                if (data.status) {
                    (statusBackground as GradientDrawable).setColor(
                        ContextCompat.getColor(
                            root.context,
                            R.color.green
                        )
                    );
                    tvPondStatus.text = "Sudah Panen"
                } else {
                    (statusBackground as GradientDrawable).setColor(
                        ContextCompat.getColor(
                            root.context,
                            R.color.primary_color
                        )
                    );
                    tvPondStatus.text = "Belum Panen"
                }
                tvLobsterType.text = data.lobsterType
                tvNumberOfLobster.text = binding.root.context.resources.getString(
                    R.string.number_of_lobster_vaue_text,
                    data.numberOfLobster
                )
                tvPondLength.text = HtmlCompat.fromHtml(
                    "<font>${data.length}</font> <small>cm</small>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                tvPondWidth.text = HtmlCompat.fromHtml(
                    "<font>${data.width}</font> <small>cm</small>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                tvPondHeight.text = HtmlCompat.fromHtml(
                    "<font>${data.height}</font> <small>cm</small>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
            }
        }

        init {
            binding.root.setOnClickListener {
                onItemClick?.invoke(listData[adapterPosition])
            }

            binding.root.setOnLongClickListener {
                onItemLongClick?.invoke(listData[adapterPosition])
                true
            }
        }
    }
}