package com.example.simtaster.presentation.home

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.core.data.Resource
import com.example.core.domain.model.Pond
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentHomeBinding
import com.example.simtaster.presentation.dialog.AddPondDialog
import com.example.simtaster.presentation.dialog.AddPondDialog.Companion.ADD_ACTION
import com.example.simtaster.presentation.dialog.AddPondDialog.Companion.UPDATE_ACTION
import com.example.simtaster.presentation.dialog.ProgressBarDialog
import com.example.simtaster.utils.commitDialog
import com.example.simtaster.utils.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.koin.androidx.viewmodel.ext.android.viewModel

class HomeFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val homeViewModel: HomeViewModel by viewModel()

    private lateinit var homeAdapter: HomeAdapter
    private lateinit var addPondDialog: AddPondDialog
    private lateinit var progressBarDialog: ProgressBarDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        homeAdapter = HomeAdapter()
        homeAdapter.onItemClick = { pond ->
            showStatistics(pond)
        }
        homeAdapter.onItemLongClick = { pond ->
            showPondMenu(pond)
        }
        with(binding.rvPond) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = homeAdapter
        }

        binding.fabAddPond.setOnClickListener(this)

        getAllPond()
    }

    private fun getAllPond() {
        binding.progressbar.visibility = View.VISIBLE
        homeViewModel.getAllPond().observe(viewLifecycleOwner, { response ->
            binding.progressbar.visibility = View.GONE
            when (response) {
                is Resource.Success -> {
                    response.data?.let { list ->
                        homeAdapter.setData(list)
                        binding.viewEmpty.root.visibility =
                            if (list.isNotEmpty()) View.GONE else View.VISIBLE
                    }

                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun showStatistics(pond: Pond) {
        val navigate = HomeFragmentDirections.actionHomeFragmentToStatisticsFragment(
            pond,
            pond.lobsterType
        )
        findNavController().navigate(navigate)
    }

    private fun showPondMenu(pond: Pond) {
        val items = arrayOf(
            resources.getString(R.string.see_statistics_text),
            resources.getString(R.string.update_pond_text),
            resources.getString(R.string.delete_pond_text)
        )

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(resources.getString(R.string.menu_text))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        showStatistics(pond)
                    }
                    1 -> {
                        showAddPondDialog(true, UPDATE_ACTION, pond)
                    }
                    2 -> {
                        deletePondDialog(pond.id)
                    }
                }
            }
            .show()
    }

    private fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ) {
        showProgressBar(true)
        homeViewModel.addPond(
            lobsterType,
            numberOfLobster,
            pondLength,
            pondWidth,
            pondHeight,
            ipAddress,
            password
        ).observe(viewLifecycleOwner, { response ->
            showProgressBar(false)
            when (response) {
                is Resource.Success -> {
                    context?.toast(response.message.toString())
                    showAddPondDialog(false)
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun showAddPondDialog(visible: Boolean, type: String = "", pond: Pond? = null) {
        if (visible) {
            addPondDialog = AddPondDialog()
            addPondDialog.setData(type, pond)
            addPondDialog.onButtonClick =
                { actionType, pondId, lobsterType, numberOfLobster, pondLength, pondWidth, pondHeight, ipAddress, password ->
                    if (lobsterType.isBlank() || numberOfLobster.isBlank() || pondLength.isBlank() || pondWidth.isBlank() || pondHeight.isBlank()) {
                        context?.toast(resources.getString(R.string.data_not_complete_text))
                    } else {
                        if (actionType == ADD_ACTION) {
                            addPond(
                                lobsterType,
                                numberOfLobster,
                                pondLength,
                                pondWidth,
                                pondHeight,
                                ipAddress,
                                password
                            )
                        } else {
                            updatePond(
                                pondId,
                                lobsterType,
                                numberOfLobster,
                                pondLength,
                                pondWidth,
                                pondHeight,
                                ipAddress,
                                password
                            )
                        }
                    }
                }

            commitDialog(addPondDialog, ADD_POND_DIALOG_TAG)
        } else {
            addPondDialog.dismiss()
        }
    }

    private fun deletePondDialog(pondId: String) {
        MaterialAlertDialogBuilder(binding.root.context)
            .setTitle(resources.getString(R.string.delete_pond_text))
            .setMessage(resources.getString(R.string.delete_pond_message))
            .setNegativeButton(resources.getString(R.string.no_text)) { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton(resources.getString(R.string.yes_text)) { _, _ ->
                deletePond(pondId)
            }
            .show()
    }

    private fun deletePond(pondId: String) {
        homeViewModel.deletePond(pondId).observe(viewLifecycleOwner, { response ->
            when (response) {
                is Resource.Success -> {
                    context?.toast(response.message.toString())
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ) {
        showProgressBar(true)
        homeViewModel.updatePond(
            pondId,
            lobsterType,
            numberOfLobster,
            pondLength,
            pondWidth,
            pondHeight,
            ipAddress,
            password
        ).observe(viewLifecycleOwner, { response ->
            showProgressBar(false)
            when (response) {
                is Resource.Success -> {
                    context?.toast(response.message.toString())
                    showAddPondDialog(false)
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun checkVNCViewerInstalled(): Boolean {
        val packageManager: PackageManager? = context?.packageManager

        return try {
            packageManager?.getPackageInfo(
                "com.realvnc.viewer.android",
                PackageManager.GET_ACTIVITIES
            )
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun goToCamera() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.apply {
            component = ComponentName(
                "com.realvnc.viewer.android",
                "com.realvnc.viewer.android.app.ConnectionChooserActivity"
            )
        }
        startActivity(intent)
    }

    private fun showProgressBar(visible: Boolean) {
        if (visible) {
            progressBarDialog = ProgressBarDialog()

            commitDialog(progressBarDialog, PROGRESS_DIALOG_TAG)
        } else {
            progressBarDialog.dismiss()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.main_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.reminder_item -> findNavController().navigate(R.id.action_homeFragment_to_reminderFragment)
            R.id.profile_item -> findNavController().navigate(R.id.action_homeFragment_to_profileFragment)
            R.id.camera_item -> {
                if (checkVNCViewerInstalled()) goToCamera()
                else context?.toast(
                    resources.getString(
                        R.string.vnc_not_installed
                    )
                )
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onClick(view: View) {
        when (view) {
            binding.fabAddPond -> {
                showAddPondDialog(true, ADD_ACTION)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        binding.rvPond.adapter = null
        _binding = null
    }

    companion object {
        const val ADD_POND_DIALOG_TAG = "add pond dialog"
        const val PROGRESS_DIALOG_TAG = "progress dialog"
    }
}