package com.example.simtaster.presentation.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.model.Pond
import com.example.core.domain.usecase.pond.AddPondUseCase
import com.example.core.domain.usecase.pond.DeletePondUseCase
import com.example.core.domain.usecase.pond.GetPondUseCase
import com.example.core.domain.usecase.pond.UpdatePondUseCase

class HomeViewModel(
    private val getPondUseCase: GetPondUseCase,
    private val addPondUseCase: AddPondUseCase,
    private val deletePondUseCase: DeletePondUseCase,
    private val updatePondUseCase: UpdatePondUseCase
) : ViewModel() {
    fun getAllPond(): LiveData<Resource<List<Pond>>> =
        LiveDataReactiveStreams.fromPublisher(getPondUseCase.getAllPond())

    fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): LiveData<Resource<String>> = LiveDataReactiveStreams.fromPublisher(
        addPondUseCase.addPond(
            lobsterType,
            numberOfLobster,
            pondLength,
            pondWidth,
            pondHeight,
            ipAddress,
            password
        )
    )

    fun deletePond(pondId: String): LiveData<Resource<String>> =
        LiveDataReactiveStreams.fromPublisher(deletePondUseCase.deletePond(pondId))

    fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): LiveData<Resource<String>> = LiveDataReactiveStreams.fromPublisher(
        updatePondUseCase.updatePond(
            pondId,
            lobsterType,
            numberOfLobster,
            pondLength,
            pondWidth,
            pondHeight,
            ipAddress,
            password
        )
    )
}