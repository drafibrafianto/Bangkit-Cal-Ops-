package com.example.simtaster.presentation.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.core.data.Resource
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentLoginBinding
import com.example.simtaster.presentation.dialog.ProgressBarDialog
import com.example.simtaster.utils.commitDialog
import com.example.simtaster.utils.toast
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import org.koin.androidx.viewmodel.ext.android.viewModel

class LoginFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private val loginViewModel: LoginViewModel by viewModel()

    private lateinit var progressBarDialog: ProgressBarDialog

    override fun onStart() {
        super.onStart()

        val currentUser = Firebase.auth.currentUser

        if (currentUser != null) {
            findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnLogin.setOnClickListener(this)
        binding.btnToRegister.setOnClickListener(this)
    }

    private fun loginUser(email: String, password: String) {
        showProgressBar(true)
        loginViewModel.loginUser(email, password).observe(viewLifecycleOwner, { response ->
            showProgressBar(false)
            when (response) {
                is Resource.Success -> {
                    context?.toast(response.message.toString())
                    findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun showProgressBar(visible: Boolean) {
        if (visible) {
            progressBarDialog = ProgressBarDialog()

            commitDialog(progressBarDialog, PROGRESS_TAG)
        } else {
            progressBarDialog.dismiss()
        }
    }

    override fun onClick(view: View) {
        when (view) {
            binding.btnLogin -> {
                val email = binding.etEmail.text.toString()
                val password = binding.etPassword.text.toString()

                if (email.isBlank() || password.isBlank()) {
                    context?.toast(resources.getString(R.string.data_not_complete_text))
                } else {
                    loginUser(email, password)
                }
            }
            binding.btnToRegister -> findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    companion object {
        const val PROGRESS_TAG = "progress dialog"
    }
}