package com.example.simtaster.presentation.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.usecase.auth.LoginUseCase

class LoginViewModel(private val loginUseCase: LoginUseCase) : ViewModel() {
    fun loginUser(email: String, password: String): LiveData<Resource<String>> =
        LiveDataReactiveStreams.fromPublisher(loginUseCase.loginUser(email, password))
}