package com.example.simtaster.presentation.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.core.data.Resource
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentProfileBinding
import com.example.simtaster.utils.toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import org.koin.androidx.viewmodel.ext.android.viewModel

class ProfileFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val profileViewModel: ProfileViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getUserProfile()
        binding.btnLogout.setOnClickListener(this)
    }

    private fun getUserProfile() {
        profileViewModel.getUserProfile().observe(viewLifecycleOwner, { response ->
            when (response) {
                is Resource.Success -> {
                    with(binding) {
                        tvNameProfile.text = response.data?.name
                        tvPhoneNumberProfile.text = response.data?.phoneNumber
                        tvEmailProfile.text = response.data?.email
                    }
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun showLogoutDialog() {
        MaterialAlertDialogBuilder(binding.root.context)
            .setTitle(resources.getString(R.string.logout_text))
            .setMessage(resources.getString(R.string.logout_message_text))
            .setNegativeButton(resources.getString(R.string.no_text)) { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton(resources.getString(R.string.yes_text)) { _, _ ->
                Firebase.auth.signOut()
                findNavController().navigate(R.id.action_profileFragment_to_splashFragment)
            }
            .show()
    }

    override fun onClick(view: View) {
        when (view) {
            binding.btnLogout -> showLogoutDialog()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }
}