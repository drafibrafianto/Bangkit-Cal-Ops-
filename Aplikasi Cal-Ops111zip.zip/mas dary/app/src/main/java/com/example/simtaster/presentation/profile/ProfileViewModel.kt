package com.example.simtaster.presentation.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.model.Profile
import com.example.core.domain.usecase.profile.GetUserProfileUseCase

class ProfileViewModel(private val getUserProfileUseCase: GetUserProfileUseCase) : ViewModel() {

    fun getUserProfile(): LiveData<Resource<Profile>> =
        LiveDataReactiveStreams.fromPublisher(getUserProfileUseCase.getUserProfile())
}