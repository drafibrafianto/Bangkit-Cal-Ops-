package com.example.simtaster.presentation.realtime

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.example.core.data.Resource
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentRealtimeBinding
import com.example.simtaster.presentation.dialog.WarningDialog
import com.example.simtaster.utils.commitDialog
import com.example.simtaster.utils.toast
import org.koin.androidx.viewmodel.ext.android.viewModel

class RealtimeFragment : Fragment() {

    private var _binding: FragmentRealtimeBinding? = null
    private val binding get() = _binding!!
    private val args: RealtimeFragmentArgs by navArgs()
    private val realtimeViewModel: RealtimeViewModel by viewModel()

    private var warningDialog: WarningDialog? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRealtimeBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val pondId = args.pondId

        getRealtimeData(pondId)
    }

    private fun getRealtimeData(pondId: String) {
        realtimeViewModel.getRealtimeData(pondId).observe(viewLifecycleOwner, { response ->
            when (response) {
                is Resource.Success -> {
                    val dataRealtime = response.data?.realtimeData

                    dataRealtime?.let { data ->
                        with(binding) {
                            tvPh.text = String.format("%.1f", data.ph)
                            tvSalinity.text = String.format("%.1f", data.salinity)
                            tvOxygen.text = String.format("%.1f", data.oxygen)
                            tvTemperature.text = String.format("%.1f", data.temperature)
                        }
                        when {
                            data.salinity > 37 -> showWarningDialog(
                                true,
                                resources.getString(R.string.over_salinity_message)
                            )
                            data.salinity < 30 -> showWarningDialog(
                                true,
                                resources.getString(R.string.under_salinity_message)
                            )
                            else -> showWarningDialog(false)
                        }
                    }
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun showWarningDialog(isVisible: Boolean, message: String = "") {
        if (isVisible) {
            if (warningDialog == null) warningDialog = WarningDialog()

            warningDialog?.let { dialog ->
                dialog.onCloseButtonClick = {
                    showWarningDialog(false)
                }
                dialog.setWarningMessage(message)
                if (!dialog.isAdded) {
                    commitDialog(dialog, WARNING_DIALOG_TAG)
                }
            }
        } else {
            warningDialog?.let { dialog ->
                if (dialog.isAdded) {
                    dialog.dismiss()
                    warningDialog = null
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    companion object {
        const val WARNING_DIALOG_TAG = "warning dialog"
    }
}