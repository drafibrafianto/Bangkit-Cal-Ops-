package com.example.simtaster.presentation.realtime

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.model.Realtime
import com.example.core.domain.usecase.statistics.GetRealtimeUseCase

class RealtimeViewModel(private val getRealtimeUseCase: GetRealtimeUseCase) : ViewModel() {
    fun getRealtimeData(pondId: String): LiveData<Resource<Realtime>> =
        LiveDataReactiveStreams.fromPublisher(getRealtimeUseCase.getRealtimeData(pondId))
}