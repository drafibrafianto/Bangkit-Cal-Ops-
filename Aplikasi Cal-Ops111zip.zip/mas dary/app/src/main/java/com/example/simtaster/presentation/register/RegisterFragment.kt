package com.example.simtaster.presentation.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.core.data.Resource
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentRegisterBinding
import com.example.simtaster.presentation.dialog.ProgressBarDialog
import com.example.simtaster.utils.commitDialog
import com.example.simtaster.utils.toast
import org.koin.androidx.viewmodel.ext.android.viewModel

class RegisterFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!
    private val registerViewModel: RegisterViewModel by viewModel()

    private lateinit var progressBarDialog: ProgressBarDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnRegister.setOnClickListener(this)
        binding.btnBack.setOnClickListener(this)
        binding.btnToLogin.setOnClickListener(this)
    }

    private fun registerUser(name: String, phoneNumber: String, email: String, password: String) {
        showProgressBar(true)
        registerViewModel.registerUser(name, phoneNumber, email, password)
            .observe(viewLifecycleOwner, { response ->
                showProgressBar(false)
                when (response) {
                    is Resource.Success -> {
                        context?.toast(response.message.toString())
                        findNavController().navigate(R.id.action_registerFragment_to_homeFragment)
                    }
                    is Resource.Error -> context?.toast(response.message.toString())
                }
            })
    }

    private fun showProgressBar(visible: Boolean) {
        if (visible) {
            progressBarDialog = ProgressBarDialog()

            commitDialog(progressBarDialog, PROGRESS_TAG)
        } else {
            progressBarDialog.dismiss()
        }
    }

    override fun onClick(view: View) {
        when (view) {
            binding.btnRegister -> {
                val name = binding.etName.text.toString()
                val phoneNumber = binding.etPhoneNumber.text.toString()
                val email = binding.etEmail.text.toString()
                val password = binding.etPassword.text.toString()

                if (name.isBlank() || phoneNumber.isBlank() || email.isBlank() || password.isBlank()) {
                    context?.toast(resources.getString(R.string.data_not_complete_text))
                } else {
                    registerUser(name, phoneNumber, email, password)
                }
            }
            binding.btnBack, binding.btnToLogin -> findNavController().popBackStack()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()

        _binding = null
    }

    companion object {
        const val PROGRESS_TAG = "progress dialog"
    }
}