package com.example.simtaster.presentation.register

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.usecase.auth.RegisterUseCase

class RegisterViewModel(private val registerUseCase: RegisterUseCase) : ViewModel() {

    fun registerUser(
        name: String,
        phoneNumber: String,
        email: String,
        password: String
    ): LiveData<Resource<String>> = LiveDataReactiveStreams.fromPublisher(
        registerUseCase.registerUser(
            name,
            phoneNumber,
            email,
            password
        )
    )
}