package com.example.simtaster.presentation.reminder

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.core.domain.model.Reminder
import com.example.simtaster.databinding.ItemReminderBinding
import com.example.simtaster.utils.DateFormatter

class ReminderAdapter : RecyclerView.Adapter<ReminderAdapter.ViewHolder>() {

    private var listData = ArrayList<Reminder>()
    var onItemClick: ((Int) -> Unit)? = null

    fun setData(newListData: List<Reminder>?) {
        if (newListData == null) return
        listData.clear()
        listData.addAll(newListData)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemReminderBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listData[position])
    }

    override fun getItemCount(): Int = listData.size

    inner class ViewHolder(private val binding: ItemReminderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(data: Reminder) {
            with(binding) {
                tvDateReminder.text = DateFormatter.formatTimeMillisToDateStyle(data.reminderTime)
                tvTimeReminder.text = DateFormatter.formatTimeMillisToTimeStyle(data.reminderTime)
                tvTitleReminder.text = data.title
            }
        }

        init {
            binding.root.setOnClickListener {
                onItemClick?.invoke(listData[adapterPosition].id)
            }
        }
    }
}