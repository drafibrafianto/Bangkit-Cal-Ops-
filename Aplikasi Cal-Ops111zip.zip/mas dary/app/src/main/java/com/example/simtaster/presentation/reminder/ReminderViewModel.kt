package com.example.simtaster.presentation.reminder

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.domain.model.Reminder
import com.example.core.domain.usecase.reminder.GetReminderUseCase

class ReminderViewModel(private val getReminderUseCase: GetReminderUseCase) : ViewModel() {

    fun getAllReminder(): LiveData<List<Reminder>> =
        LiveDataReactiveStreams.fromPublisher(getReminderUseCase.getAllReminder())
}