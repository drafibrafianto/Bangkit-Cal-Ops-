package com.example.simtaster.presentation.statistics

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.example.simtaster.R
import com.example.simtaster.presentation.statistics.StatisticsFragment.Companion.ALL_TYPE
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.IMarker
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.data.DataSet
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.utils.MPPointF

class ChartWaterMarkerView(
    context: Context,
    private val lineChart: LineChart,
    layoutResource: Int,
    private val type: String
) :
    MarkerView(context, layoutResource), IMarker {
    private val square1: TextView = findViewById(R.id.square1)
    private val square2: TextView = findViewById(R.id.square2)
    private val square3: TextView = findViewById(R.id.square3)
    private val square4: TextView = findViewById(R.id.square4)
    private val item1: TextView = findViewById(R.id.item1)
    private val item2: TextView = findViewById(R.id.item2)
    private val item3: TextView = findViewById(R.id.item3)
    private val item4: TextView = findViewById(R.id.item4)
    private val linear2: LinearLayout = findViewById(R.id.lin2)
    private val linear3: LinearLayout = findViewById(R.id.lin3)
    private val linear4: LinearLayout = findViewById(R.id.lin4)
    private val title: TextView = findViewById(R.id.txtTitle)

    private val axisX = ChartXAxisFormatter("Hari")

    override fun refreshContent(e: Entry, highlight: Highlight) {
        try {
            title.text = resources.getString(
                R.string.x_axis_marker_water_text,
                (axisX.getFormattedValue(e.x).toFloat() + 1)
            )
            square1.setBackgroundColor(lineChart.data.getDataSetByIndex(0).color)
            val val1 = lineChart.data.getDataSetByIndex(0)
                .getEntryForXValue(e.x, Float.NaN, DataSet.Rounding.CLOSEST) as Entry
            item1.text = String.format("%,.1f", val1.y)

            if (type == ALL_TYPE) {
                square2.setBackgroundColor(lineChart.data.getDataSetByIndex(1).color)
                square3.setBackgroundColor(lineChart.data.getDataSetByIndex(2).color)
                square4.setBackgroundColor(lineChart.data.getDataSetByIndex(3).color)


                val val2 = lineChart.data.getDataSetByIndex(1)
                    .getEntryForXValue(e.x, Float.NaN, DataSet.Rounding.CLOSEST) as Entry
                val val3 = lineChart.data.getDataSetByIndex(2)
                    .getEntryForXValue(e.x, Float.NaN, DataSet.Rounding.CLOSEST) as Entry
                val val4 = lineChart.data.getDataSetByIndex(3)
                    .getEntryForXValue(e.x, Float.NaN, DataSet.Rounding.CLOSEST) as Entry
                item2.text = String.format("%,.1f", val2.y)
                item3.text = String.format("%,.1f", val3.y)
                item4.text = String.format("%,.1f", val4.y)
            } else {
                linear2.visibility = View.GONE
                linear3.visibility = View.GONE
                linear4.visibility = View.GONE
            }

        } catch (e: Exception) {

        }
        super.refreshContent(e, highlight)
    }

    private var mOffset: MPPointF? = null
    override fun getOffset(): MPPointF {
        if (mOffset == null) {
            mOffset = MPPointF((-(width / 2)).toFloat(), (-height).toFloat())
        }
        return mOffset!!
    }
}