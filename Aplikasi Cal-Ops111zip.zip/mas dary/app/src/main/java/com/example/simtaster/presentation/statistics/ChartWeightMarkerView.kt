package com.example.simtaster.presentation.statistics

import android.content.Context
import android.widget.TextView
import com.example.simtaster.R
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.IMarker
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.data.DataSet
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.utils.MPPointF

class ChartWeightMarkerView(
    context: Context,
    private val lineChart: LineChart,
    layoutResource: Int
) :
    MarkerView(context, layoutResource), IMarker {
    private val square1: TextView = findViewById(R.id.square1)
    private val item1: TextView = findViewById(R.id.item1)
    private val title: TextView = findViewById(R.id.txtTitle)

    private val axisX = ChartXAxisFormatter("Bulan")

    override fun refreshContent(e: Entry, highlight: Highlight) {
        try {
            title.text = resources.getString(
                R.string.x_axis_marker_weight_text,
                (axisX.getFormattedValue(e.x).toFloat() + 1)
            )
            square1.setBackgroundColor(lineChart.data.getDataSetByIndex(0).color)

            val val1 = lineChart.data.getDataSetByIndex(0)
                .getEntryForXValue(e.x, Float.NaN, DataSet.Rounding.CLOSEST) as Entry
            item1.text = String.format("%,.1f", val1.y)

        } catch (e: Exception) {

        }
        super.refreshContent(e, highlight)
    }

    private var mOffset: MPPointF? = null
    override fun getOffset(): MPPointF {
        if (mOffset == null) {
            mOffset = MPPointF((-(width / 2)).toFloat(), (-height).toFloat())
        }
        return mOffset!!
    }
}