package com.example.simtaster.presentation.statistics

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.core.domain.model.WaterStatisticsData
import com.example.simtaster.databinding.ItemStatisticsBinding

class StatisticsAdapter : RecyclerView.Adapter<StatisticsAdapter.ViewHolder>() {

    private val listData = arrayListOf<WaterStatisticsData>()

    fun setData(newListData: List<WaterStatisticsData>?) {
        if (newListData == null) return
        listData.clear()
        listData.addAll(newListData)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(
        ItemStatisticsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listData[position])
    }

    override fun getItemCount(): Int = listData.size

    inner class ViewHolder(private val binding: ItemStatisticsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(data: WaterStatisticsData) {
            with(binding) {
//                tvLobsterWeight.text = root.context.resources.getString(
//                    R.string.lobster_weight_text,
//                    data.lobsterWeight
//                )
//                tvWaterQuality.text = data.waterQuality
                tvDay.text = "Hari ${(adapterPosition + 1)}"
                tvPh.text = HtmlCompat.fromHtml(
                    "<font>pH Air</font><br /><b>${data.ph}</b>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                tvSalinity.text = HtmlCompat.fromHtml(
                    "<font>Salinitas</font><br /><b>${data.salinity}</b>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                tvOxygen.text = HtmlCompat.fromHtml(
                    "<font>Oksigen</font><br /><b>${data.oxygen}</b>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                tvTemperature.text = HtmlCompat.fromHtml(
                    "<font>Suhu air</font><br /><b>${data.temperature}</b>",
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
            }

        }
    }
}