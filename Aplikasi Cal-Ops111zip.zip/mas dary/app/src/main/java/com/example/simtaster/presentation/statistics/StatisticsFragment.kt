package com.example.simtaster.presentation.statistics

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.core.data.Resource
import com.example.core.domain.model.Pond
import com.example.core.domain.model.Statistics
import com.example.simtaster.R
import com.example.simtaster.databinding.FragmentStatisticsBinding
import com.example.simtaster.utils.toast
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import org.koin.androidx.viewmodel.ext.android.viewModel

class StatisticsFragment : Fragment() {

    private var _binding: FragmentStatisticsBinding? = null
    private val binding get() = _binding!!
    private val statisticsViewModel: StatisticsViewModel by viewModel()
    private val args: StatisticsFragmentArgs by navArgs()

    private var waterQualityType = ALL_TYPE
    private lateinit var statisticsAdapter: StatisticsAdapter
    private var weightLineDataSet: LineDataSet? = null
    private var phLineDataSet: LineDataSet? = null
    private var salinityLineDataSet: LineDataSet? = null
    private var oxygenLineDataSet: LineDataSet? = null
    private var temperatureLineDataSet: LineDataSet? = null

    private lateinit var pond: Pond

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentStatisticsBinding.inflate(inflater, container, false)

        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        pond = args.pond

        statisticsAdapter = StatisticsAdapter()

        with(binding.rvStatistics) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = statisticsAdapter
        }

        getStatistics(pond.id)

    }

    private fun getStatistics(pondId: String) {
        binding.labelLobsterWeightStatistics.visibility = View.GONE
        binding.labelWaterQualityStatistics.visibility = View.GONE
        binding.lineChartWeight.visibility = View.GONE
        binding.lineChartWaterQuality.visibility = View.GONE
        binding.rvStatistics.visibility = View.GONE
        binding.progressbar.visibility = View.VISIBLE
        statisticsViewModel.getStatistics(pondId).observe(viewLifecycleOwner, { response ->
            binding.progressbar.visibility = View.GONE
            when (response) {
                is Resource.Success -> {
                    response.data?.let {
                        if (!it.lobsterWeightStatistics.isNullOrEmpty() || !it.waterQualityStatistics.isNullOrEmpty()) {
                            binding.labelLobsterWeightStatistics.visibility = View.VISIBLE
                            binding.labelWaterQualityStatistics.visibility = View.VISIBLE
                            binding.lineChartWeight.visibility = View.VISIBLE
                            binding.lineChartWaterQuality.visibility = View.VISIBLE
                            binding.rvStatistics.visibility = View.VISIBLE
                            binding.viewEmpty.root.visibility = View.GONE
                            statisticsAdapter.setData(it.waterQualityStatistics)
                            makeDataset(it)
                            setLobsterWeightGraphics()
                            setWaterQualityGraphics(waterQualityType)
                        } else {
                            binding.labelLobsterWeightStatistics.visibility = View.GONE
                            binding.labelWaterQualityStatistics.visibility = View.GONE
                            binding.lineChartWeight.visibility = View.GONE
                            binding.lineChartWaterQuality.visibility = View.GONE
                            binding.rvStatistics.visibility = View.GONE
                            binding.viewEmpty.root.visibility = View.VISIBLE
                        }
                    }
                }
                is Resource.Error -> context?.toast(response.message.toString())
            }
        })
    }

    private fun makeDataset(statistics: Statistics) {
        val weight = statistics.lobsterWeightStatistics.mapIndexed { index, data ->
            Entry(
                index.toFloat(),
                data
            )
        }
        val ph = statistics.waterQualityStatistics.mapIndexed { index, statisticsData ->
            Entry(
                index.toFloat(),
                statisticsData.ph
            )
        }
        val salinity = statistics.waterQualityStatistics.mapIndexed { index, statisticsData ->
            Entry(
                index.toFloat(),
                statisticsData.salinity
            )
        }
        val oxygen = statistics.waterQualityStatistics.mapIndexed { index, statisticsData ->
            Entry(
                index.toFloat(),
                statisticsData.oxygen
            )
        }
        val temperature = statistics.waterQualityStatistics.mapIndexed { index, statisticsData ->
            Entry(
                index.toFloat(),
                statisticsData.temperature
            )
        }

        weightLineDataSet = LineDataSet(weight, resources.getString(R.string.weight_text))
        with(weightLineDataSet) {
            this?.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            this?.color = ContextCompat.getColor(binding.root.context, R.color.primary_color)
            this?.circleRadius = 5f
            this?.setCircleColor(
                ContextCompat.getColor(
                    binding.root.context,
                    R.color.primary_color
                )
            )
        }

        phLineDataSet = LineDataSet(ph, resources.getString(R.string.ph_text))
        with(phLineDataSet) {
            this?.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            this?.color = ContextCompat.getColor(binding.root.context, R.color.green)
            this?.circleRadius = 5f
            this?.setCircleColor(ContextCompat.getColor(binding.root.context, R.color.green))
        }

        salinityLineDataSet = LineDataSet(salinity, resources.getString(R.string.salinity_text))
        with(salinityLineDataSet) {
            this?.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            this?.color = ContextCompat.getColor(binding.root.context, R.color.red)
            this?.circleRadius = 5f
            this?.setCircleColor(ContextCompat.getColor(binding.root.context, R.color.red))
        }

        oxygenLineDataSet = LineDataSet(oxygen, resources.getString(R.string.oxygen_text))
        with(oxygenLineDataSet) {
            this?.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            this?.color = ContextCompat.getColor(binding.root.context, R.color.blue)
            this?.circleRadius = 5f
            this?.setCircleColor(ContextCompat.getColor(binding.root.context, R.color.blue))
        }

        temperatureLineDataSet =
            LineDataSet(temperature, resources.getString(R.string.temperature_text))
        with(temperatureLineDataSet) {
            this?.mode = LineDataSet.Mode.HORIZONTAL_BEZIER
            this?.color = ContextCompat.getColor(binding.root.context, R.color.purple_700)
            this?.circleRadius = 5f
            this?.setCircleColor(ContextCompat.getColor(binding.root.context, R.color.purple_700))
        }
    }

    private fun setLobsterWeightGraphics() {
        with(binding.lineChartWeight) {
            legend.isEnabled = true
            legend.verticalAlignment = Legend.LegendVerticalAlignment.TOP
            legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
            legend.orientation = Legend.LegendOrientation.HORIZONTAL
            legend.setDrawInside(false)

            description.isEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.axisMinimum = 0f
            xAxis.granularity = 1f
            xAxis.valueFormatter = ChartXAxisFormatter(resources.getString(R.string.month_text))
            animateX(500)

            setDrawMarkers(false)
            marker = ChartWeightMarkerView(context, this, R.layout.view_marker_weight)
            data = LineData(weightLineDataSet)

            setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                override fun onValueSelected(e: Entry?, h: Highlight?) {
                    setDrawMarkers(true)
                }

                override fun onNothingSelected() {
                    setDrawMarkers(false)
                }
            })
        }
    }

    private fun setWaterQualityGraphics(type: String) {
        waterQualityType = type

        with(binding.lineChartWaterQuality) {
            legend.isEnabled = true
            legend.verticalAlignment = Legend.LegendVerticalAlignment.TOP
            legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
            legend.orientation = Legend.LegendOrientation.HORIZONTAL
            legend.setDrawInside(false)

            description.isEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.axisMinimum = 0f
            xAxis.granularity = 1f
            xAxis.valueFormatter = ChartXAxisFormatter(resources.getString(R.string.day_text))
            animateX(500)

            setDrawMarkers(false)
            marker =
                ChartWaterMarkerView(context, this, R.layout.view_marker_water, waterQualityType)

            when (waterQualityType) {
                ALL_TYPE -> data = LineData(
                    phLineDataSet,
                    salinityLineDataSet,
                    oxygenLineDataSet,
                    temperatureLineDataSet
                )
                PH_TYPE -> data = LineData(phLineDataSet)
                SALINITY_TYPE -> data = LineData(salinityLineDataSet)
                OXYGEN_TYPE -> data = LineData(oxygenLineDataSet)
                TEMPERATURE_TYPE -> data = LineData(temperatureLineDataSet)
            }

            setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                override fun onValueSelected(e: Entry?, h: Highlight?) {
                    setDrawMarkers(true)
                }

                override fun onNothingSelected() {
                    setDrawMarkers(false)
                }

            })
        }
    }

    private fun checkVNCViewerInstalled(): Boolean {
        val packageManager: PackageManager? = context?.packageManager

        return try {
            packageManager?.getPackageInfo(
                "com.realvnc.viewer.android",
                PackageManager.GET_ACTIVITIES
            )
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun goToCamera() {
        val cmd = "vnc://${pond.ipAddress}/C24bit/${pond.password}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(cmd))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.statistics_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.realtime_item -> {
                val navigate =
                    StatisticsFragmentDirections.actionStatisticsFragmentToRealTimeFragment(pond.id)
                findNavController().navigate(navigate)
            }
            R.id.camera_item -> {
                if (checkVNCViewerInstalled()) {
                    if (pond.ipAddress.isNotEmpty() || pond.password.isNotEmpty()) goToCamera()
                    else context?.toast(resources.getString(R.string.ip_address_or_password_empty))
                } else {
                    context?.toast(resources.getString(R.string.vnc_not_installed))
                }
            }
            R.id.all_item -> if (weightLineDataSet != null) setWaterQualityGraphics(ALL_TYPE)
            R.id.ph_item -> if (phLineDataSet != null) setWaterQualityGraphics(PH_TYPE)
            R.id.salinity_item -> if (salinityLineDataSet != null) setWaterQualityGraphics(
                SALINITY_TYPE
            )
            R.id.oxygen_item -> if (oxygenLineDataSet != null) setWaterQualityGraphics(OXYGEN_TYPE)
            R.id.temperature_item -> if (temperatureLineDataSet != null) setWaterQualityGraphics(
                TEMPERATURE_TYPE
            )
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroyView() {
        super.onDestroyView()

        binding.rvStatistics.adapter = null
        _binding = null
    }

    companion object {
        const val ALL_TYPE = "all"
        const val PH_TYPE = "ph"
        const val SALINITY_TYPE = "salinity"
        const val OXYGEN_TYPE = "oxygen"
        const val TEMPERATURE_TYPE = "temperature"
    }
}