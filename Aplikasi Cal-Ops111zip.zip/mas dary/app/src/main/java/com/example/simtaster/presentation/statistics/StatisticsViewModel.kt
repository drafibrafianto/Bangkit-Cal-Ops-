package com.example.simtaster.presentation.statistics

import androidx.lifecycle.LiveData
import androidx.lifecycle.LiveDataReactiveStreams
import androidx.lifecycle.ViewModel
import com.example.core.data.Resource
import com.example.core.domain.model.Statistics
import com.example.core.domain.usecase.statistics.GetStatisticsUseCase

class StatisticsViewModel(
    private val getStatisticsUseCase: GetStatisticsUseCase
) : ViewModel() {
    fun getStatistics(pondId: String): LiveData<Resource<Statistics>> =
        LiveDataReactiveStreams.fromPublisher(getStatisticsUseCase.getStatistics(pondId))
}