package com.example.simtaster.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ALARM_ID = "AlarmId"
        const val ALARM_TITLE = "Title"
        const val TYPE_ONE_TIME = "OneTimeAlarm"
        const val TYPE_REPEATING = "RepeatingAlarm"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra(ALARM_ID, 0)
        val title = intent.getStringExtra(ALARM_TITLE) as String

        startAlarmService(context, alarmId, title)
    }

    fun setAlarm(
        context: Context,
        type: String,
        alarmId: Int,
        reminderTime: Long,
        title: String,
        isAdd: Boolean
    ) {

        val intent = Intent(context, AlarmReceiver::class.java)
        intent.putExtra(ALARM_ID, alarmId)
        intent.putExtra(ALARM_TITLE, title)

        val pendingIntent: PendingIntent = if (isAdd) {
            PendingIntent.getBroadcast(context, alarmId, intent, 0)
        } else {
            PendingIntent.getBroadcast(
                context,
                alarmId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        if (type == TYPE_ONE_TIME) {
            setOneTimeAlarm(context, pendingIntent, reminderTime)
        } else {
            setRepeatingAlarm(context, pendingIntent, reminderTime)
        }
    }

    private fun setOneTimeAlarm(
        context: Context,
        pendingIntent: PendingIntent,
        reminderTime: Long
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        if (Build.VERSION.SDK_INT >= 23) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                reminderTime,
                pendingIntent
            )
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                reminderTime,
                pendingIntent
            )
        }
    }

    private fun setRepeatingAlarm(
        context: Context,
        pendingIntent: PendingIntent,
        reminderTime: Long,
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val interval = AlarmManager.INTERVAL_DAY

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            reminderTime,
            interval,
            pendingIntent
        )
    }

    private fun startAlarmService(
        context: Context,
        alarmId: Int,
        title: String,
    ) {
        val serviceIntent = Intent(context, AlarmService::class.java)
        serviceIntent.putExtra(ALARM_ID, alarmId)
        serviceIntent.putExtra(ALARM_TITLE, title)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }

    fun cancelAlarm(context: Context, alarmId: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(context, alarmId, intent, 0)
        pendingIntent.cancel()

        alarmManager.cancel(pendingIntent)
    }
}