package com.example.simtaster.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.example.simtaster.R
import com.example.simtaster.presentation.alarm.AlarmActivity

class AlarmService : Service() {

    private val channelId = "alarm_channel"

    private lateinit var notificationManager: NotificationManager
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var vibrator: Vibrator

    override fun onCreate() {
        super.onCreate()

        val uri = Uri.parse("android.resource://$packageName/${R.raw.alarm}")
        mediaPlayer = MediaPlayer().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            } else {
                setAudioStreamType(AudioManager.STREAM_ALARM)
            }
            setDataSource(applicationContext, uri)
            isLooping = true
            prepare()
        }

        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Alarm Pentungan",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarm Aplikasi Pentungan"
            }

            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            val alarmId = intent.getIntExtra(AlarmReceiver.ALARM_ID, 0)
            val title = intent.getStringExtra(AlarmReceiver.ALARM_TITLE)

            showNotification(alarmId, title)
        }

        mediaPlayer.start()
        vibrateStart()

        return START_STICKY
    }

    private fun showNotification(id: Int, title: String?) {
        val fullScreenIntent = Intent(this, AlarmActivity::class.java)
        fullScreenIntent.putExtra(AlarmReceiver.ALARM_ID, id)

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, 0,
            fullScreenIntent, PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder =
            NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_app_logo_splash)
                .setContentTitle(title)
                .setContentIntent(fullScreenPendingIntent)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(fullScreenPendingIntent)

        val notification = builder.build()

        notificationManager.notify(id, notification)

        startForeground(id, notification)

    }

    private fun vibrateStart() {
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(
                VibrationEffect.createWaveform(
                    longArrayOf(
                        1000,
                        1000,
                        1000,
                        1000,
                        1000
                    ), 0
                )
            )
        } else {
            vibrator.vibrate(longArrayOf(1000, 1000, 1000, 1000, 1000), 0)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        mediaPlayer.stop()
        vibrator.cancel()
        notificationManager.cancelAll()
        stopForeground(true)
        stopSelf()
    }
}