package com.example.simtaster.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.simtaster.preference.ReminderPreference
import com.example.simtaster.utils.Constant.reminderTypeList

class BootCompleteReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "android.intent.action.BOOT_COMPLETED") {
            val reminderPreference = ReminderPreference(context)
            val alarmReceiver = AlarmReceiver()

            val listReminder = reminderPreference.getReminder()

            listReminder.forEach { reminder ->
                if (reminder.reminderType == reminderTypeList[0]) {
                    alarmReceiver.setAlarm(
                        context,
                        AlarmReceiver.TYPE_ONE_TIME,
                        reminder.id,
                        reminder.reminderTime,
                        reminder.title,
                        true
                    )
                } else {
                    alarmReceiver.setAlarm(
                        context,
                        AlarmReceiver.TYPE_REPEATING,
                        reminder.id,
                        reminder.reminderTime,
                        reminder.title,
                        true
                    )
                }
            }
        }
    }
}