package com.example.simtaster.utils

object Constant {
    val reminderTypeList = listOf("Sekali Saja", "Setiap Hari")
}