package com.example.simtaster.utils

import java.text.SimpleDateFormat
import java.util.*

object DateFormatter {
    fun formatTimeMillisToDateAlarmStyle(timeInMillis: Long): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        return dateFormat.format(timeInMillis)
    }

    fun formatTimeMillisToDateStyle(timeInMillis: Long): String {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

        return dateFormat.format(timeInMillis)
    }

    fun formatTimeMillisToTimeStyle(timeInMillis: Long): String {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        return timeFormat.format(timeInMillis)
    }
}