package com.example.simtaster.utils

import android.content.Context
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment

fun Context.toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

fun Fragment.commitDialog(dialog: DialogFragment, tag: String) {
    val fragmentTransaction = childFragmentManager.beginTransaction()
    fragmentTransaction.apply {
        add(dialog, tag)
        addToBackStack(null)
    }.commit()
}

fun DialogFragment.dismissDialog() {
    val fragmentManager = childFragmentManager
    val fragmentTransaction = fragmentManager.beginTransaction()
    if (fragmentManager.backStackEntryCount > 0) fragmentManager.popBackStack()
    fragmentTransaction.commit()
}