package com.example.simtaster.utils

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

object Permission {

    fun overlayPermission(context: Context?, activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(context)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                val uri = Uri.fromParts("package", context?.packageName, null)

                intent.data = uri
                activity.startActivityForResult(intent, 109)
                return
            }
        }
    }

    fun ignoreBatteryOptimizationPermission(context: Context?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent()
            val packageName = context?.packageName
            val pm = context?.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                intent.action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                intent.data = Uri.parse("package:$packageName")
                context.startActivity(intent)

                autoStartPermission(context)
            }
        }
    }

    private fun autoStartPermission(context: Context) {
        try {
            val intent = Intent()
            when (Build.MANUFACTURER.lowercase()) {
                "xiaomi" ->
                    intent.component =
                        ComponentName(
                            "com.miui.securitycenter",
                            "com.miui.permcenter.autostart.AutoStartManagementActivity"
                        )
                "oppo" -> {
                    try {
                        intent.component =
                            ComponentName(
                                "com.coloros.safecenter",
                                "com.coloros.safecenter.permission.startup.StartupAppListActivity"
                            )
                    } catch (e2: Exception) {
                        try {
                            intent.component =
                                ComponentName(
                                    "com.oppo.safe",
                                    "com.oppo.safe.permission.startup.StartupAppListActivity"
                                )
                        } catch (e3: Exception) {
                            try {
                                intent.component =
                                    ComponentName(
                                        "com.coloros.safecenter",
                                        "com.coloros.safecenter.startup.StartupAppListActivity"
                                    )
                            } catch (e4: Exception) {

                            }
                        }
                    }
                }
                "vivo" ->
                    intent.component =
                        ComponentName(
                            "com.vivo.permissionmanager",
                            "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                        )

                "letv" ->
                    intent.component =
                        ComponentName(
                            "com.letv.android.letvsafe",
                            "com.letv.android.letvsafe.AutobootManageActivity"
                        )
                "honor" ->
                    intent.component =
                        ComponentName(
                            "com.huawei.systemmanager",
                            "com.huawei.systemmanager.optimize.process.ProtectActivity"
                        )

                else -> context.toast("Auto start telah diaktifkan")
            }

            val list =
                context.packageManager.queryIntentActivities(
                    intent,
                    PackageManager.MATCH_DEFAULT_ONLY
                )
            if (list.size > 0) {
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            context.toast("Terjadi kesalahan")
        }
    }
}