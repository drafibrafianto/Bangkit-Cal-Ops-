package com.example.core.data

import com.example.core.data.source.local.LocalDataSource
import com.example.core.data.source.remote.RemoteDataSource
import com.example.core.domain.model.*
import com.example.core.domain.repository.IRepository
import com.example.core.utils.DataMapper
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.BackpressureStrategy
import io.reactivex.rxjava3.core.Flowable
import io.reactivex.rxjava3.schedulers.Schedulers
import io.reactivex.rxjava3.subjects.PublishSubject

class AppRepository(
    private val remoteDataSource: RemoteDataSource,
    private val localDataSource: LocalDataSource
) : IRepository {

    override fun registerUser(
        name: String,
        phoneNumber: String,
        email: String,
        password: String
    ): Flowable<Resource<String>> {
        val resultData = PublishSubject.create<Resource<String>>()

        remoteDataSource.createAccount(email, password)
            .flatMap { userId -> remoteDataSource.saveUserData(userId, name, phoneNumber, email) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).take(1).subscribe({
                resultData.onNext(Resource.Success("Berhasil membuat akun"))
            }, {
                resultData.onNext(Resource.Error("Gagal membuat akun"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun loginUser(email: String, password: String): Flowable<Resource<String>> {
        val resultData = PublishSubject.create<Resource<String>>()

        remoteDataSource.loginUser(email, password).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).take(1).subscribe({
                resultData.onNext(Resource.Success("Login berhasil"))
            }, {
                resultData.onNext(Resource.Error("Login gagal"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>> {
        val resultData = PublishSubject.create<Resource<String>>()

        remoteDataSource.addPond(lobsterType, numberOfLobster, pondLength, pondWidth, pondHeight, ipAddress, password)
            .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).take(1)
            .subscribe({
                resultData.onNext(Resource.Success("Data kolam berhasil ditambahkan"))
            }, {
                resultData.onNext(Resource.Error("Data kolam gagal ditambahkan"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getAllPond(): Flowable<Resource<List<Pond>>> {
        val resultData = PublishSubject.create<Resource<List<Pond>>>()

        remoteDataSource.getAllPond().subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({ response ->
                resultData.onNext(Resource.Success(data = response))
            }, {
                resultData.onNext(Resource.Error("Gagal mengambil data kolam"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun deletePond(pondId: String): Flowable<Resource<String>> {
        val resultData = PublishSubject.create<Resource<String>>()

        remoteDataSource.deletePond(pondId)
            .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).take(1)
            .subscribe({
                resultData.onNext(Resource.Success("Data kolam berhasil dihapus"))
            }, {
                resultData.onNext(Resource.Error("Data kolam gagal dihapus"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>> {
        val resultData = PublishSubject.create<Resource<String>>()

        remoteDataSource.updatePond(
            pondId,
            lobsterType,
            numberOfLobster,
            pondLength,
            pondWidth,
            pondHeight,
            ipAddress,
            password
        )
            .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).take(1)
            .subscribe({
                resultData.onNext(Resource.Success("Data kolam berhasil diperbarui"))
            }, {
                resultData.onNext(Resource.Error("Data kolam gagal diperbarui"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getStatistics(pondId: String): Flowable<Resource<Statistics>> {
        val resultData = PublishSubject.create<Resource<Statistics>>()

        remoteDataSource.getStatistics(pondId).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({ response ->
                resultData.onNext(Resource.Success(data = response))
            }, {
                resultData.onNext(Resource.Error("Gagal mengambil data statistik kolam"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getRealtimeData(pondId: String): Flowable<Resource<Realtime>> {
        val resultData = PublishSubject.create<Resource<Realtime>>()

        remoteDataSource.getRealtimeData(pondId).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({ response ->
                resultData.onNext(Resource.Success(data = response))
            }, {
                resultData.onNext(Resource.Error("Gagal mengambil data terkini"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getUserProfile(): Flowable<Resource<Profile>> {
        val resultData = PublishSubject.create<Resource<Profile>>()

        remoteDataSource.getUserProfile().subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe({ response ->
                resultData.onNext(Resource.Success(data = response))
            }, {
                resultData.onNext(Resource.Error("Gagal mengambil data pengguna"))
            })

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun insertReminder(reminder: Reminder): Flowable<Long> {
        val resultData = PublishSubject.create<Long>()

        val reminderEntity = DataMapper.mapReminderDomainToEntity(reminder)

        localDataSource.insertReminder(reminderEntity).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { id ->
                resultData.onNext(id)
            }

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getAllReminder(): Flowable<List<Reminder>> {
        val resultData = PublishSubject.create<List<Reminder>>()

        localDataSource.getAllReminder().subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe { list ->
                resultData.onNext(DataMapper.mapReminderEntitiesToDomain(list))
            }

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun getReminderById(reminderId: Int): Flowable<Reminder> {
        val resultData = PublishSubject.create<Reminder>()

        localDataSource.getReminderById(reminderId).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe { response ->
                resultData.onNext(DataMapper.mapReminderEntityToDomain(response))
            }

        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }

    override fun deleteReminder(reminder: Reminder) {
        val reminderEntity = DataMapper.mapReminderDomainToEntity(reminder)

        localDataSource.deleteReminder(reminderEntity).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe()
    }

    override fun updateReminderTime(reminderId: Int, reminderTime: Long) {
        localDataSource.updateReminderTime(reminderId, reminderTime).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe()
    }

    override fun updateReminder(reminder: Reminder) {
        val reminderEntity = DataMapper.mapReminderDomainToEntity(reminder)

        localDataSource.updateReminder(reminderEntity).subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread()).subscribe()
    }
}