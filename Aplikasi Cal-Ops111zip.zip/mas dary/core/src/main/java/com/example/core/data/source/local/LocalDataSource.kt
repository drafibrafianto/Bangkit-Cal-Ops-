package com.example.core.data.source.local

import com.example.core.data.source.local.entity.ReminderEntity
import com.example.core.data.source.local.room.ReminderDao
import io.reactivex.rxjava3.core.Completable
import io.reactivex.rxjava3.core.Flowable
import io.reactivex.rxjava3.core.Single

class LocalDataSource(private val reminderDao: ReminderDao) {
    fun insertReminder(reminderEntity: ReminderEntity): Single<Long> =
        reminderDao.saveReminder(reminderEntity)

    fun getAllReminder(): Flowable<List<ReminderEntity>> = reminderDao.getAllReminder()

    fun getReminderById(reminderId: Int): Flowable<ReminderEntity> =
        reminderDao.getReminderById(reminderId)

    fun deleteReminder(reminderEntity: ReminderEntity): Completable =
        reminderDao.deleteReminder(reminderEntity)

    fun updateReminderTime(reminderId: Int, reminderTime: Long): Completable =
        reminderDao.updateReminderTime(reminderId, reminderTime)

    fun updateReminder(reminder: ReminderEntity): Completable = reminderDao.updateReminder(reminder)
}