package com.example.core.data.source.local.room

import androidx.room.*
import com.example.core.data.source.local.entity.ReminderEntity
import io.reactivex.rxjava3.core.Completable
import io.reactivex.rxjava3.core.Flowable
import io.reactivex.rxjava3.core.Single

@Dao
interface ReminderDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun saveReminder(reminderEntity: ReminderEntity): Single<Long>

    @Query("SELECT * FROM reminder ORDER BY reminderTime ASC")
    fun getAllReminder(): Flowable<List<ReminderEntity>>

    @Query("SELECT * FROM reminder WHERE id = :reminderId")
    fun getReminderById(reminderId: Int): Flowable<ReminderEntity>

    @Delete
    fun deleteReminder(reminderEntity: ReminderEntity): Completable

    @Query("UPDATE reminder SET reminderTime = :reminderTime WHERE id = :reminderId")
    fun updateReminderTime(reminderId: Int, reminderTime: Long): Completable

    @Update
    fun updateReminder(reminder: ReminderEntity): Completable
}