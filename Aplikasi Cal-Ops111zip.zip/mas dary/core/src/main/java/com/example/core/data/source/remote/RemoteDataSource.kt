package com.example.core.data.source.remote

import com.example.core.domain.model.Pond
import com.example.core.domain.model.Profile
import com.example.core.domain.model.Realtime
import com.example.core.domain.model.Statistics
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import io.reactivex.rxjava3.core.BackpressureStrategy
import io.reactivex.rxjava3.core.Flowable

class RemoteDataSource(
    private val firebaseAuth: FirebaseAuth,
    private val firebaseFirestore: FirebaseFirestore
) {

    fun createAccount(email: String, password: String): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener {
                emitter.onNext(it.user?.uid)
            }.addOnFailureListener {
                emitter.onError(it)
            }
        }, BackpressureStrategy.BUFFER)
    }

    fun saveUserData(
        userId: String,
        name: String,
        phoneNumber: String,
        email: String
    ): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseFirestore.collection("data").document(userId)
                .set(hashMapOf("name" to name, "phoneNumber" to phoneNumber, "email" to email))
                .addOnSuccessListener {
                    emitter.onNext("")
                }.addOnFailureListener {
                    emitter.onError(it)
                }
        }, BackpressureStrategy.BUFFER)
    }

    fun loginUser(email: String, password: String): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnSuccessListener {
                emitter.onNext(it.user?.uid)
            }.addOnFailureListener {
                emitter.onError(it)
            }
        }, BackpressureStrategy.BUFFER)
    }

    fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseFirestore.collection("data").document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").add(
                    hashMapOf(
                        "lobsterType" to lobsterType,
                        "numberOfLobster" to numberOfLobster,
                        "length" to pondLength,
                        "width" to pondWidth,
                        "height" to pondHeight,
                        "ipAddress" to ipAddress,
                        "password" to password,
                        "status" to false,
                        "timestamp" to Timestamp.now()
                    )
                ).addOnSuccessListener {
                    emitter.onNext(it.id)
                }.addOnFailureListener {
                    emitter.onError(it)
                }
        }, BackpressureStrategy.BUFFER)
    }

    fun getAllPond(): Flowable<List<Pond>> {
        return Flowable.create({ emitter ->
            val listener = firebaseFirestore.collection("data")
                .document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { value, error ->
                    value?.let { snapshot ->
                        val pondList = snapshot.map {
                            Pond(
                                it.id,
                                it.getString("lobsterType") ?: "",
                                it.getString("numberOfLobster") ?: "",
                                it.getString("length") ?: "",
                                it.getString("width") ?: "",
                                it.getString("height") ?: "",
                                it["status"] as Boolean,
                                it.getString("ipAddress") ?: "",
                                it.getString("password") ?: ""
                            )
                        }
                        emitter.onNext(pondList)
                    }

                    error?.let {
                        emitter.onError(it)
                    }
                }

            emitter.setCancellable { listener.remove() }
        }, BackpressureStrategy.BUFFER)
    }

    fun deletePond(pondId: String): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseFirestore.collection("data").document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").document(pondId).delete().addOnSuccessListener {
                    emitter.onNext("")
                }.addOnFailureListener {
                    emitter.onError(it)
                }
        }, BackpressureStrategy.BUFFER)
    }

    fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<String> {
        return Flowable.create({ emitter ->
            firebaseFirestore.collection("data").document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").document(pondId).update(
                    mapOf(
                        "lobsterType" to lobsterType,
                        "numberOfLobster" to numberOfLobster,
                        "length" to pondLength,
                        "width" to pondWidth,
                        "height" to pondHeight,
                        "ipAddress" to ipAddress,
                        "password" to password,
                    )
                ).addOnSuccessListener {
                    emitter.onNext("")
                }.addOnFailureListener {
                    emitter.onError(it)
                }
        }, BackpressureStrategy.BUFFER)
    }

    fun getStatistics(pondId: String): Flowable<Statistics> {
        return Flowable.create({ emitter ->
            val listener = firebaseFirestore.collection("data")
                .document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").document(pondId).addSnapshotListener { value, error ->
                    value?.let { snapshot ->
                        val statistics = snapshot.toObject(Statistics::class.java)

                        emitter.onNext(statistics)
                    }

                    error?.let {
                        emitter.onError(it)
                    }
                }
            emitter.setCancellable { listener.remove() }
        }, BackpressureStrategy.BUFFER)
    }

    fun getRealtimeData(pondId: String): Flowable<Realtime> {
        return Flowable.create({ emitter ->
            val listener = firebaseFirestore.collection("data")
                .document(firebaseAuth.currentUser?.uid.toString())
                .collection("pond").document(pondId).addSnapshotListener { value, error ->
                    value?.let { snapshot ->
                        val statistics = snapshot.toObject(Realtime::class.java)

                        emitter.onNext(statistics)
                    }

                    error?.let {
                        emitter.onError(it)
                    }
                }
            emitter.setCancellable { listener.remove() }
        }, BackpressureStrategy.BUFFER)
    }

    fun getUserProfile(): Flowable<Profile> {
        return Flowable.create({ emitter ->
            val listener = firebaseFirestore.collection("data")
                .document(firebaseAuth.currentUser?.uid.toString())
                .addSnapshotListener { value, error ->
                    value?.let { snapshot ->
                        val profile = snapshot.toObject(Profile::class.java)

                        emitter.onNext(profile)
                    }

                    error?.let {
                        emitter.onError(it)
                    }
                }

            emitter.setCancellable { listener.remove() }
        }, BackpressureStrategy.BUFFER)
    }
}