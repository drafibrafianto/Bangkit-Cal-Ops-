package com.example.core.di

import androidx.room.Room
import com.example.core.data.AppRepository
import com.example.core.data.source.local.LocalDataSource
import com.example.core.data.source.local.room.AppDatabase
import com.example.core.data.source.remote.RemoteDataSource
import com.example.core.domain.repository.IRepository
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val databaseModule = module {
    single { get<AppDatabase>().reminderDao() }
    single {
        Room.databaseBuilder(
            androidContext(),
            AppDatabase::class.java, "Simtaster.db"
        ).fallbackToDestructiveMigration().build()
    }
}

val networkModule = module {
    single { Firebase.auth }
    single { Firebase.firestore }
}

val repositoryModule = module {
    single { LocalDataSource(get()) }
    single { RemoteDataSource(get(), get()) }
    single<IRepository> { AppRepository(get(), get()) }
}