package com.example.core.domain.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Pond(
    val id: String,
    val lobsterType: String,
    val numberOfLobster: String,
    val length: String,
    val width: String,
    val height: String,
    val status: Boolean,
    val ipAddress: String,
    val password: String
): Parcelable