package com.example.core.domain.model

data class Profile(
    val name: String = "",
    val email: String = "",
    val phoneNumber: String = ""
)