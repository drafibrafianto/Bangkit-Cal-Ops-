package com.example.core.domain.model

data class Realtime(
    val realtimeData: WaterStatisticsData = WaterStatisticsData(0f, 0f, 0f, 0f)
)