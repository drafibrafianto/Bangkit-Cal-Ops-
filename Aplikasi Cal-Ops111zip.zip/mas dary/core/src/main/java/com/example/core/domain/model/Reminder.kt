package com.example.core.domain.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Reminder(
    var id: Int,
    var title: String,
    var reminderTime: Long,
    var reminderType: String
) : Parcelable