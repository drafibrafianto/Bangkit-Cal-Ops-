package com.example.core.domain.model

data class Statistics(
    val lobsterWeightStatistics: List<Float> = listOf(),
    val waterQualityStatistics: List<WaterStatisticsData> = listOf()
)