package com.example.core.domain.model

data class WaterStatisticsData(
    val oxygen: Float = 0f,
    val ph: Float = 0f,
    val salinity: Float = 0f,
    val temperature: Float = 0f
)