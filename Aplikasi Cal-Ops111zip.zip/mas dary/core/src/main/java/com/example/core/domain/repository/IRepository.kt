package com.example.core.domain.repository

import com.example.core.data.Resource
import com.example.core.domain.model.*
import io.reactivex.rxjava3.core.Flowable

interface IRepository {
    fun registerUser(
        name: String,
        phoneNumber: String,
        email: String,
        password: String
    ): Flowable<Resource<String>>

    fun loginUser(email: String, password: String): Flowable<Resource<String>>

    fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>>

    fun getAllPond(): Flowable<Resource<List<Pond>>>

    fun deletePond(pondId: String): Flowable<Resource<String>>

    fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>>

    fun getStatistics(pondId: String): Flowable<Resource<Statistics>>

    fun getRealtimeData(pondId: String): Flowable<Resource<Realtime>>

    fun getUserProfile(): Flowable<Resource<Profile>>

    fun insertReminder(reminder: Reminder): Flowable<Long>

    fun getAllReminder(): Flowable<List<Reminder>>

    fun getReminderById(reminderId: Int): Flowable<Reminder>

    fun deleteReminder(reminder: Reminder)

    fun updateReminderTime(reminderId: Int, reminderTime: Long)

    fun updateReminder(reminder: Reminder)
}