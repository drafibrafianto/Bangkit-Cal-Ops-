package com.example.core.domain.usecase.auth

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class LoginInteractor(private val repository: IRepository) : LoginUseCase {
    override fun loginUser(email: String, password: String): Flowable<Resource<String>> =
        repository.loginUser(email, password)
}