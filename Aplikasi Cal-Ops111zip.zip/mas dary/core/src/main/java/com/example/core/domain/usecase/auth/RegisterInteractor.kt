package com.example.core.domain.usecase.auth

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class RegisterInteractor(private val repository: IRepository) : RegisterUseCase {
    override fun registerUser(
        name: String,
        phoneNumber: String,
        email: String,
        password: String
    ): Flowable<Resource<String>> = repository.registerUser(name, phoneNumber, email, password)
}