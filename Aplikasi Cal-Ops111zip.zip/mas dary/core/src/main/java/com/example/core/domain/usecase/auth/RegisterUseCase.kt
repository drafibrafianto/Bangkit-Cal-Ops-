package com.example.core.domain.usecase.auth

import com.example.core.data.Resource
import io.reactivex.rxjava3.core.Flowable

interface RegisterUseCase {
    fun registerUser(
        name: String,
        phoneNumber: String,
        email: String,
        password: String
    ): Flowable<Resource<String>>
}