package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class AddPondInteractor(private val repository: IRepository) : AddPondUseCase {
    override fun addPond(
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>> =
        repository.addPond(lobsterType, numberOfLobster, pondLength, pondWidth, pondHeight, ipAddress, password)
}