package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class DeletePondInteractor(private val repository: IRepository) : DeletePondUseCase {
    override fun deletePond(pondId: String): Flowable<Resource<String>> =
        repository.deletePond(pondId)
}