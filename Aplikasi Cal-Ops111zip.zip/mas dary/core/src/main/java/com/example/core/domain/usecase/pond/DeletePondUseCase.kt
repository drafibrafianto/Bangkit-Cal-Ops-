package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import io.reactivex.rxjava3.core.Flowable

interface DeletePondUseCase {
    fun deletePond(pondId: String): Flowable<Resource<String>>
}