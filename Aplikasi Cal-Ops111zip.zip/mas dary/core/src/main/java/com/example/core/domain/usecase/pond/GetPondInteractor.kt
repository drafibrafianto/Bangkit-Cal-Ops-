package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import com.example.core.domain.model.Pond
import io.reactivex.rxjava3.core.Flowable

class GetPondInteractor(private val repository: IRepository) : GetPondUseCase {
    override fun getAllPond(): Flowable<Resource<List<Pond>>> = repository.getAllPond()
}