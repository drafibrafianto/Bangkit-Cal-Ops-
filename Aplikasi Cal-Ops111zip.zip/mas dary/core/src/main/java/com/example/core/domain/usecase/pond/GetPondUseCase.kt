package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import com.example.core.domain.model.Pond
import io.reactivex.rxjava3.core.Flowable

interface GetPondUseCase {
    fun getAllPond(): Flowable<Resource<List<Pond>>>
}