package com.example.core.domain.usecase.pond

import com.example.core.data.Resource
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class UpdatePondInteractor(private val repository: IRepository) : UpdatePondUseCase {
    override fun updatePond(
        pondId: String,
        lobsterType: String,
        numberOfLobster: String,
        pondLength: String,
        pondWidth: String,
        pondHeight: String,
        ipAddress: String,
        password: String
    ): Flowable<Resource<String>> = repository.updatePond(
        pondId,
        lobsterType,
        numberOfLobster,
        pondLength,
        pondWidth,
        pondHeight,
        ipAddress,
        password
    )
}