package com.example.core.domain.usecase.profile

import com.example.core.data.Resource
import com.example.core.domain.model.Profile
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class GetUserProfileInteractor(private val repository: IRepository) : GetUserProfileUseCase {

    override fun getUserProfile(): Flowable<Resource<Profile>> = repository.getUserProfile()
}