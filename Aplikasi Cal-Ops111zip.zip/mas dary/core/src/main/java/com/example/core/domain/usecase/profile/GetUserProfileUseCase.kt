package com.example.core.domain.usecase.profile

import com.example.core.data.Resource
import com.example.core.domain.model.Profile
import io.reactivex.rxjava3.core.Flowable

interface GetUserProfileUseCase {
    fun getUserProfile(): Flowable<Resource<Profile>>
}