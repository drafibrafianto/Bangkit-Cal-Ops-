package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import com.example.core.domain.repository.IRepository

class DeleteReminderInteractor(private val repository: IRepository) : DeleteReminderUseCase {
    override fun deleteReminder(reminder: Reminder) = repository.deleteReminder(reminder)
}