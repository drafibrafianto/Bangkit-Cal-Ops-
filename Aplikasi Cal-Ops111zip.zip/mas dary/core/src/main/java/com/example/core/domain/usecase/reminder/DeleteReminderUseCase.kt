package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder

interface DeleteReminderUseCase {
    fun deleteReminder(reminder: Reminder)
}