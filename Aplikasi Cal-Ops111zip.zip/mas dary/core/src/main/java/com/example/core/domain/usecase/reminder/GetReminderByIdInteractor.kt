package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class GetReminderByIdInteractor(private val repository: IRepository) : GetReminderByIdUseCase {
    override fun getReminderById(reminderId: Int): Flowable<Reminder> =
        repository.getReminderById(reminderId)
}