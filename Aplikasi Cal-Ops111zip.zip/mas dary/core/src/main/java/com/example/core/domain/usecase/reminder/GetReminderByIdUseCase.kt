package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import io.reactivex.rxjava3.core.Flowable

interface GetReminderByIdUseCase {
    fun getReminderById(reminderId: Int): Flowable<Reminder>
}