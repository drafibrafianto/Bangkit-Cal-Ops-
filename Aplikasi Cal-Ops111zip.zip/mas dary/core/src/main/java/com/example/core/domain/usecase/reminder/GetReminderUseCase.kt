package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import io.reactivex.rxjava3.core.Flowable

interface GetReminderUseCase {
    fun getAllReminder(): Flowable<List<Reminder>>
}