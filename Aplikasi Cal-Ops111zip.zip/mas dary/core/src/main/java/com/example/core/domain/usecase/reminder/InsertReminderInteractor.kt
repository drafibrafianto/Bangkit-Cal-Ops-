package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import com.example.core.domain.repository.IRepository

class InsertReminderInteractor(private val repository: IRepository) : InsertReminderUseCase {
    override fun insertReminder(reminder: Reminder) = repository.insertReminder(reminder)
}