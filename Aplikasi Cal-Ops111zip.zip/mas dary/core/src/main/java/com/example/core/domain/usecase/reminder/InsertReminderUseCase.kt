package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import io.reactivex.rxjava3.core.Flowable

interface InsertReminderUseCase {
    fun insertReminder(reminder: Reminder): Flowable<Long>
}