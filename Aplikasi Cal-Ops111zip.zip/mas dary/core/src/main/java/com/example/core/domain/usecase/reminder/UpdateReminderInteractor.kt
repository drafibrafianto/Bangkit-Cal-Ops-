package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder
import com.example.core.domain.repository.IRepository

class UpdateReminderInteractor(private val repository: IRepository) : UpdateReminderUseCase {
    override fun updateReminder(reminder: Reminder) = repository.updateReminder(reminder)
}