package com.example.core.domain.usecase.reminder

import com.example.core.domain.model.Reminder

interface UpdateReminderUseCase {
    fun updateReminder(reminder: Reminder)
}