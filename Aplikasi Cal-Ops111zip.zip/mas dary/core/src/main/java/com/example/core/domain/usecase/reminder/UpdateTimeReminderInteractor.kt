package com.example.core.domain.usecase.reminder

import com.example.core.domain.repository.IRepository

class UpdateTimeReminderInteractor(private val repository: IRepository) :
    UpdateTimeReminderUseCase {

    override fun updateReminderTime(reminderId: Int, reminderTime: Long) =
        repository.updateReminderTime(reminderId, reminderTime)
}