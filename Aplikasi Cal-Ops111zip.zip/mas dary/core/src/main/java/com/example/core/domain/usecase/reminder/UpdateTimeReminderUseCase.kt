package com.example.core.domain.usecase.reminder

interface UpdateTimeReminderUseCase {
    fun updateReminderTime(reminderId: Int, reminderTime: Long)
}