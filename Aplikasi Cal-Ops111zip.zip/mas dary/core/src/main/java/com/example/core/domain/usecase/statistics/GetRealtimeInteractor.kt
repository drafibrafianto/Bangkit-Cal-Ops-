package com.example.core.domain.usecase.statistics

import com.example.core.data.Resource
import com.example.core.domain.model.Realtime
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class GetRealtimeInteractor(private val repository: IRepository) : GetRealtimeUseCase {
    override fun getRealtimeData(pondId: String): Flowable<Resource<Realtime>> =
        repository.getRealtimeData(pondId)
}