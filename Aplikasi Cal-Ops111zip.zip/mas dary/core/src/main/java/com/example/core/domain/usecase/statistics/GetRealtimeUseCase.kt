package com.example.core.domain.usecase.statistics

import com.example.core.data.Resource
import com.example.core.domain.model.Realtime
import io.reactivex.rxjava3.core.Flowable

interface GetRealtimeUseCase {
    fun getRealtimeData(pondId: String): Flowable<Resource<Realtime>>
}