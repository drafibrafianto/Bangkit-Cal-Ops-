package com.example.core.domain.usecase.statistics

import com.example.core.data.Resource
import com.example.core.domain.model.Statistics
import com.example.core.domain.repository.IRepository
import io.reactivex.rxjava3.core.Flowable

class GetStatisticsInteractor(private val repository: IRepository) : GetStatisticsUseCase {
    override fun getStatistics(pondId: String): Flowable<Resource<Statistics>> =
        repository.getStatistics(pondId)
}