package com.example.core.domain.usecase.statistics

import com.example.core.data.Resource
import com.example.core.domain.model.Statistics
import io.reactivex.rxjava3.core.Flowable

interface GetStatisticsUseCase {
    fun getStatistics(pondId: String): Flowable<Resource<Statistics>>
}