package com.example.core.utils

import com.example.core.data.source.local.entity.ReminderEntity
import com.example.core.domain.model.Reminder

object DataMapper {
    fun mapReminderDomainToEntity(reminder: Reminder) = ReminderEntity(
        id = reminder.id,
        title = reminder.title,
        reminderTime = reminder.reminderTime,
        reminderType = reminder.reminderType
    )

    fun mapReminderEntitiesToDomain(reminderList: List<ReminderEntity>) = reminderList.map {
        Reminder(it.id, it.title, it.reminderTime, it.reminderType)
    }

    fun mapReminderEntityToDomain(reminderEntity: ReminderEntity): Reminder = Reminder(
        id = reminderEntity.id,
        title = reminderEntity.title,
        reminderTime = reminderEntity.reminderTime,
        reminderType = reminderEntity.reminderType
    )
}